import tkinter as tk
from gui import SmartStudyApp

if __name__ == '__main__':
    root = tk.Tk()
    app = SmartStudyApp(root)
    root.mainloop()
