import random
from flashcards import get_all_cards

def generate_quiz_question():
    cards = get_all_cards()
    if len(cards) < 3:
        return None  # Not enough cards

    correct = random.choice(cards)
    others = random.sample([c for c in cards if c != correct], 2)

    choices = [correct['answer'], others[0]['answer'], others[1]['answer']]
    random.shuffle(choices)

    return {
        'question': correct['question'],
        'choices': choices,
        'correct': correct['answer']
    }
