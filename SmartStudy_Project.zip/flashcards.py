import json
import random

FLASHCARDS_FILE = 'flashcards.json'

def load_flashcards():
    try:
        with open(FLASHCARDS_FILE, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_flashcard(question, answer):
    cards = load_flashcards()
    cards.append({'question': question, 'answer': answer})
    with open(FLASHCARDS_FILE, 'w') as file:
        json.dump(cards, file, indent=2)

def get_random_card():
    cards = load_flashcards()
    return random.choice(cards) if cards else None

def get_all_cards():
    return load_flashcards()
