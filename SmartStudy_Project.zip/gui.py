import tkinter as tk
from tkinter import messagebox
from flashcards import save_flashcard, get_random_card
from summarizer import summarize_text
from quiz import generate_quiz_question

class SmartStudyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SmartStudy Assistant")

        self.tabs = tk.Frame(root)
        self.tabs.pack(pady=10)

        self.flashcard_ui()
        self.summarizer_ui()
        self.quiz_ui()

    def flashcard_ui(self):
        frame = tk.LabelFrame(self.root, text="Flashcards")
        frame.pack(padx=10, pady=5, fill="x")

        self.q_entry = tk.Entry(frame, width=40)
        self.q_entry.grid(row=0, column=1, padx=5, pady=5)
        tk.Label(frame, text="Question:").grid(row=0, column=0)

        self.a_entry = tk.Entry(frame, width=40)
        self.a_entry.grid(row=1, column=1, padx=5, pady=5)
        tk.Label(frame, text="Answer:").grid(row=1, column=0)

        tk.Button(frame, text="Save Flashcard", command=self.save_card).grid(row=2, column=0, columnspan=2, pady=5)

    def save_card(self):
        q = self.q_entry.get()
        a = self.a_entry.get()
        if q and a:
            save_flashcard(q, a)
            messagebox.showinfo("Saved", "Flashcard saved!")
            self.q_entry.delete(0, tk.END)
            self.a_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Error", "Enter both question and answer")

    def summarizer_ui(self):
        frame = tk.LabelFrame(self.root, text="Summarizer")
        frame.pack(padx=10, pady=5, fill="x")

        self.note_text = tk.Text(frame, height=5, width=60)
        self.note_text.pack(padx=5, pady=5)

        self.summary_label = tk.Label(frame, text="", wraplength=400, fg="blue")
        self.summary_label.pack()

        tk.Button(frame, text="Summarize", command=self.summarize).pack(pady=5)

    def summarize(self):
        text = self.note_text.get("1.0", tk.END)
        if text.strip():
            summary = summarize_text(text)
            self.summary_label.config(text=summary)
        else:
            messagebox.showwarning("Error", "Please enter some text")

    def quiz_ui(self):
        frame = tk.LabelFrame(self.root, text="Quiz")
        frame.pack(padx=10, pady=5, fill="x")

        self.quiz_q = tk.Label(frame, text="", wraplength=400, font=('Arial', 12, 'bold'))
        self.quiz_q.pack(pady=5)

        self.quiz_buttons = []
        for i in range(3):
            btn = tk.Button(frame, text="", width=40, command=lambda b=i: self.check_answer(b))
            btn.pack(pady=2)
            self.quiz_buttons.append(btn)

        tk.Button(frame, text="Next Question", command=self.load_question).pack(pady=5)
        self.load_question()

    def load_question(self):
        self.current_q = generate_quiz_question()
        if not self.current_q:
            self.quiz_q.config(text="Not enough flashcards to create a quiz.")
            for btn in self.quiz_buttons:
                btn.config(state="disabled", text="")
            return

        self.quiz_q.config(text=self.current_q['question'])
        for i, choice in enumerate(self.current_q['choices']):
            self.quiz_buttons[i].config(text=choice, state="normal")

    def check_answer(self, index):
        answer = self.quiz_buttons[index]['text']
        if answer == self.current_q['correct']:
            messagebox.showinfo("Correct!", "That's right! 🎉")
        else:
            messagebox.showerror("Wrong", f"Correct answer: {self.current_q['correct']}")
        self.load_question()
